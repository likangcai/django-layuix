# Generated migration for menu multilingual fields and userprofile theme

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('django_layui_rbac', '0002_systemconfig'),
    ]

    operations = [
        migrations.AddField(
            model_name='menu',
            name='name_en',
            field=models.CharField(blank=True, default='', max_length=50, verbose_name='菜单名称（英文）'),
        ),
        migrations.AddField(
            model_name='menu',
            name='name_zh_hans',
            field=models.CharField(blank=True, default='', max_length=50, verbose_name='菜单名称（简体中文）'),
        ),
        migrations.AddField(
            model_name='menu',
            name='name_zh_hant',
            field=models.CharField(blank=True, default='', max_length=50, verbose_name='菜单名称（繁体中文）'),
        ),
        migrations.AlterField(
            model_name='menu',
            name='name',
            field=models.CharField(max_length=50, verbose_name='菜单名称（中文）'),
        ),
        migrations.AlterField(
            model_name='userprofile',
            name='theme',
            field=models.CharField(default='dark', max_length=50, verbose_name='主题'),
        ),
    ]
