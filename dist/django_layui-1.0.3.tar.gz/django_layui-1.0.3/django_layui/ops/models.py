# -*- coding: utf-8 -*-
"""
django-layui Ops Models
Server management for SSH connections
"""
from django.db import models


class Server(models.Model):
    """服务器模型"""
    name = models.CharField(max_length=100, verbose_name='服务器名称')
    host = models.CharField(max_length=200, verbose_name='主机地址')
    port = models.IntegerField(default=22, verbose_name='SSH端口')
    username = models.CharField(max_length=100, verbose_name='SSH用户名')
    auth_type = models.CharField(max_length=20, choices=(
        ('password', '密码认证'),
        ('key', '密钥认证')
    ), default='password', verbose_name='认证方式')
    password = models.CharField(max_length=500, blank=True, default='', verbose_name='密码')
    private_key = models.TextField(blank=True, default='', verbose_name='私钥')
    description = models.TextField(blank=True, default='', verbose_name='描述')
    is_active = models.BooleanField(default=True, verbose_name='状态')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        db_table = 'ops_server'
        verbose_name = '服务器管理'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def __str__(self):
        return f'{self.name} ({self.host})'

    def get_ssh_client(self):
        """获取 SSH 连接客户端"""
        import paramiko
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            if self.auth_type == 'key' and self.private_key:
                import io
                key_file = io.StringIO(self.private_key)
                # Try different key types
                pkey = None
                for key_cls in [paramiko.RSAKey, paramiko.ECDSAKey, paramiko.Ed25519Key]:
                    try:
                        pkey = key_cls.from_private_key(key_file)
                        break
                    except paramiko.SSHException:
                        key_file.seek(0)
                        continue
                if pkey is None:
                    raise ValueError('无法解析私钥，请检查格式（支持 RSA/ECDSA/Ed25519）')
                client.connect(
                    hostname=self.host,
                    port=self.port,
                    username=self.username,
                    pkey=pkey,
                    timeout=10,
                    allow_agent=False,
                    look_for_keys=False
                )
            else:
                client.connect(
                    hostname=self.host,
                    port=self.port,
                    username=self.username,
                    password=self.password,
                    timeout=10,
                    allow_agent=False,
                    look_for_keys=False
                )
        except Exception as e:
            client.close()
            raise
        return client
