from django.contrib import admin
from .models import Server


class ServerAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'host', 'port', 'username', 'auth_type', 'is_active']
    list_filter = ['auth_type', 'is_active']
    search_fields = ['name', 'host', 'username']
    list_editable = ['is_active']
    exclude = ['password', 'private_key']  # Don't show sensitive fields in list

    fieldsets = (
        ('基本信息', {
            'fields': ('name', 'host', 'port', 'username', 'description')
        }),
        ('认证信息', {
            'fields': ('auth_type', 'password', 'private_key'),
            'classes': ('wide',)
        }),
        ('状态', {
            'fields': ('is_active',)
        }),
    )


admin.site.register(Server, ServerAdmin)
