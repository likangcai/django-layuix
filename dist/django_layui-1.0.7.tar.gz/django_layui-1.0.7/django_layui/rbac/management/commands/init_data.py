# -*- coding: utf-8 -*-
"""
数据初始化管理命令
用法: python manage.py init_data

功能：在 init_menu 的基础上增加创建超级管理员功能
"""
from django.core.management.base import BaseCommand
from django.core.management import call_command
from django_layui.rbac.models import Role, UserProfile


class Command(BaseCommand):
    help = '初始化系统数据：创建超级管理员 + 执行 init_menu（角色、菜单、系统配置）'

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('开始初始化系统数据...'))

        # 1. 先执行 init_menu 创建角色、菜单和系统配置
        self.stdout.write('  执行 init_menu...')
        call_command('init_menu')

        # 2. 创建超级管理员用户
        self._create_admin()

        # 3. 绑定超级管理员角色给 admin 用户
        self._bind_admin_role()

        self.stdout.write(self.style.SUCCESS('系统数据初始化完成!'))
        self.stdout.write(self.style.SUCCESS('超级管理员账号: admin / admin123'))

    def _create_admin(self):
        """创建超级管理员用户"""
        self.stdout.write('  创建超级管理员...')
        if UserProfile.objects.filter(username='admin').exists():
            self.stdout.write(self.style.WARNING('    超级管理员已存在，跳过'))
            return

        # 创建超级管理员（不传入 status 参数，创建后单独设置）
        admin = UserProfile.objects.create_superuser(
            username='admin',
            email='admin@example.com',
            password='admin123',
            nickname='超级管理员',
        )
        # 单独设置 status 字段
        admin.status = True
        admin.save()
        
        self.stdout.write(self.style.SUCCESS('    超级管理员创建成功'))

    def _bind_admin_role(self):
        """绑定超级管理员角色给 admin 用户"""
        self.stdout.write('  绑定超级管理员角色...')
        try:
            admin_user = UserProfile.objects.get(username='admin')
            admin_role = Role.objects.get(code='admin')
            
            if admin_role in admin_user.roles.all():
                self.stdout.write(self.style.WARNING('    超级管理员角色已绑定，跳过'))
                return
            
            admin_user.roles.add(admin_role)
            self.stdout.write(self.style.SUCCESS('    超级管理员角色绑定成功'))
        except UserProfile.DoesNotExist:
            self.stdout.write(self.style.WARNING('    未找到 admin 用户'))
        except Role.DoesNotExist:
            self.stdout.write(self.style.WARNING('    未找到超级管理员角色'))
