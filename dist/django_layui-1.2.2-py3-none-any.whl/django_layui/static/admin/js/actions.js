/*global gettext, interpolate, ngettext, Actions*/
'use strict';
{
    function show(selector) {
        document.querySelectorAll(selector).forEach(function(el) {
            el.classList.remove('hidden');
        });
    }

    function hide(selector) {
        document.querySelectorAll(selector).forEach(function(el) {
            el.classList.add('hidden');
        });
    }

    function showQuestion(options) {
        hide(options.acrossClears);
        show(options.acrossQuestions);
        hide(options.allContainer);
    }

    function showClear(options) {
        show(options.acrossClears);
        hide(options.acrossQuestions);
        var ac = document.querySelector(options.actionContainer);
        if (ac) ac.classList.remove(options.selectedClass);
        show(options.allContainer);
        hide(options.counterContainer);
    }

    function reset(options) {
        hide(options.acrossClears);
        hide(options.acrossQuestions);
        hide(options.allContainer);
        show(options.counterContainer);
    }

    function clearAcross(options) {
        reset(options);
        var acrossInputs = document.querySelectorAll(options.acrossInput);
        acrossInputs.forEach(function(acrossInput) {
            acrossInput.value = 0;
        });
        var ac = document.querySelector(options.actionContainer);
        if (ac) ac.classList.remove(options.selectedClass);
    }

    function checker(actionCheckboxes, options, checked) {
        if (checked) {
            showQuestion(options);
        } else {
            reset(options);
        }
        actionCheckboxes.forEach(function(el) {
            el.checked = checked;
            var tr = el.closest('tr');
            if (tr) tr.classList.toggle(options.selectedClass, checked);
        });
    }

    function updateCounter(actionCheckboxes, options) {
        var sel = Array.from(actionCheckboxes).filter(function(el) {
            return el.checked;
        }).length;
        var counter = document.querySelector(options.counterContainer);
        if (!counter) return;  // FIX: null check
        // data-actions-icnt is defined in the generated HTML
        // and contains the total amount of objects in the queryset
        var actions_icnt = Number(counter.dataset.actionsIcnt);
        counter.textContent = interpolate(
            ngettext('%(sel)s of %(cnt)s selected', '%(sel)s of %(cnt)s selected', sel), {
                sel: sel,
                cnt: actions_icnt
            }, true);
        var allToggle = document.getElementById(options.allToggleId);
        if (!allToggle) return;  // FIX: null check
        allToggle.checked = sel === actionCheckboxes.length;
        if (allToggle.checked) {
            showQuestion(options);
        } else {
            clearAcross(options);
        }
    }

    var defaults = {
        actionContainer: "div.actions",
        counterContainer: "span.action-counter",
        allContainer: "div.actions span.all",
        acrossInput: "div.actions input.select-across",
        acrossQuestions: "div.actions span.question",
        acrossClears: "div.actions span.clear",
        allToggleId: "action-toggle",
        selectedClass: "selected"
    };

    window.Actions = function(actionCheckboxes, options) {
        options = Object.assign({}, defaults, options);
        var list_editable_changed = false;
        var lastChecked = null;
        var shiftPressed = false;

        document.addEventListener('keydown', function(event) {
            shiftPressed = event.shiftKey;
        });

        document.addEventListener('keyup', function(event) {
            shiftPressed = event.shiftKey;
        });

        var allToggle = document.getElementById(options.allToggleId);
        if (allToggle) {  // FIX: null check
            allToggle.addEventListener('click', function(event) {
                checker(actionCheckboxes, options, this.checked);
                updateCounter(actionCheckboxes, options);
            });
        }

        document.querySelectorAll(options.acrossQuestions + " a").forEach(function(el) {
            el.addEventListener('click', function(event) {
                event.preventDefault();
                var acrossInputs = document.querySelectorAll(options.acrossInput);
                acrossInputs.forEach(function(acrossInput) {
                    acrossInput.value = 1;
                });
                showClear(options);
            });
        });

        document.querySelectorAll(options.acrossClears + " a").forEach(function(el) {
            el.addEventListener('click', function(event) {
                event.preventDefault();
                var toggle = document.getElementById(options.allToggleId);
                if (toggle) toggle.checked = false;
                clearAcross(options);
                checker(actionCheckboxes, options, false);
                updateCounter(actionCheckboxes, options);
            });
        });

        function affectedCheckboxes(target, withModifier) {
            var multiSelect = (lastChecked && withModifier && lastChecked !== target);
            if (!multiSelect) {
                return [target];
            }
            var checkboxes = Array.from(actionCheckboxes);
            var targetIndex = checkboxes.findIndex(function(el) { return el === target; });
            var lastCheckedIndex = checkboxes.findIndex(function(el) { return el === lastChecked; });
            var startIndex = Math.min(targetIndex, lastCheckedIndex);
            var endIndex = Math.max(targetIndex, lastCheckedIndex);
            var filtered = checkboxes.filter(function(el, index) {
                return (startIndex <= index) && (index <= endIndex);
            });
            return filtered;
        }

        var resultList = document.getElementById('result_list');
        if (resultList) {  // FIX: null check
            Array.from(resultList.tBodies).forEach(function(el) {
                el.addEventListener('change', function(event) {
                    var target = event.target;
                    if (target.classList.contains('action-select')) {
                        var checkboxes = affectedCheckboxes(target, shiftPressed);
                        checker(checkboxes, options, target.checked);
                        updateCounter(actionCheckboxes, options);
                        lastChecked = target;
                    } else {
                        list_editable_changed = true;
                    }
                });
            });
        }

        var form = document.querySelector('#changelist-form');
        if (form) {  // FIX: null check
            var saveBtn = form.querySelector('button[name=index]');
            if (saveBtn) {
                saveBtn.addEventListener('click', function(event) {
                    if (list_editable_changed) {
                        var confirmed = confirm(gettext("You have unsaved changes on individual editable fields. If you run an action, your unsaved changes will be lost."));
                        if (!confirmed) {
                            event.preventDefault();
                        }
                    }
                });
            }

            var saveInput = form.querySelector('input[name=_save]');
            if (saveInput) {
                saveInput.addEventListener('click', function(event) {
                    var actionEl = document.querySelector('[name=action]');
                    if (actionEl && actionEl.value) {
                        var text = list_editable_changed
                            ? gettext("You have selected an action, but you haven't saved your changes to individual fields yet. Please click OK to save. You'll need to re-run the action.")
                            : gettext("You have selected an action, and you haven't made any changes on individual fields. You're probably looking for the Go button rather than the Save button.");
                        if (!confirm(text)) {
                            event.preventDefault();
                        }
                    }
                });
            }
        }

        // Sync counter when navigating to the page, such as through the back button.
        window.addEventListener('pageshow', function(event) {
            updateCounter(actionCheckboxes, options);
        });
    };

    function ready(fn) {
        if (document.readyState !== 'loading') {
            fn();
        } else {
            document.addEventListener('DOMContentLoaded', fn);
        }
    }

    ready(function() {
        var actionsEls = document.querySelectorAll('tr input.action-select');
        if (actionsEls.length > 0) {
            window.Actions(actionsEls);
        }
    });
}
